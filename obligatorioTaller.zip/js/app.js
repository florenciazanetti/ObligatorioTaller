function mostrarDatos(datos){
alert(datos.apikey)
loscalStorage.setItem('token', datos.apikey);
}

function display_toast(mensaje, header, color){
    const toast = document.createElement('ion-toast');
    toast.header = header;
    toast.icon = 'information-circle',
    toast.position = 'top';
    toast.message = mensaje;
    toast.duration = 3000;
    toast.color = color;
    document.body.appendChild(toast);
    toast.present();
}

function login(data, router){
    sessionStorage.setItem("token", data.apikey);
    sessionStorage.setItem("usuario", JSON.stringify(data.usuario))
    router.push('/monedas');
}

window.onload = function mostrarListado(){
    let token = sessionStorage.getItem("token");
    const url = 'https://crypto.develotion.com/monedas.php';
    fetch(url, {
        headers:{
            "Content-type":"application/json",
            "Authorization": `Bearer ${token}` //ARREGLAR SEGUN LA API
        }
    }).then(respuesta => (respuesta.ok)?respuesta.json():respuesta.json().then(data => Promise.reject(data.mensaje)))
    .then(data => listarLocales(data)) 
    .catch(mensaje => alert(mensaje))
}
const APIurl = 'https://crypto.develotion.com';

document.getElementById('btnRegistro').onclick = function(){
    try{
        const usuario = document.getElementById('txtUsuario2').value;
        const password = document.getElementById('txtPassword2').value;
        const departamento = document.getElementById('txtDepartamento').value;
        const ciudad = document.getElementById('txtCiudad').value;
        
        if(!usuario){
            throw 'Usuario requerido para continuar';
        }
        if(!password){
            throw 'Contraseña requerida para continuar';
        }
        if(!departamento){
            throw 'Departamento requerido para continuar';
        }
        if(!ciudad){
            throw 'Ciudad requerida para continuar';
        }
        
        const url = APIurl +'/usuarios.php';
        const datos = {
            "usuario": usuario,
            "password": password,
            "departamento": departamento,
            "ciudad":ciudad
        }
        fetch(url, {
            method:'POST',
            body: JSON.stringify(datos),
            headers:{
                "Content-type":"application/json"
            }
        }).then(respuesta =>(respuesta.ok)?respuesta.json():respuesta.json().then(data => Promise.reject(data.error)))
        .then(data => router.push('/'))
        .catch(mensaje => display_toast(mensaje,'Info','primary'))
    }   
    catch(e){
        display_toast(e,'Info','primary');
    }
}


document.getElementById('btnLogin').onclick = function(){
    const usuario = document.getElementById('txtUsuario').value;
    const password = document.getElementById('txtPassword').value;
    try{
        if(!usuario){
            throw 'Usuario requerido';
        }
        if(!password){
            throw 'Contraseña requerida';
        }
        const url = APIurl + '/login.php';
        const datos = {
            "usuario": usuario,
            "password": password
        }
        fetch(url, {
            method:'POST',
            body: JSON.stringify(datos),
            headers:{
                "Content-type": "application/json"
            }
        }).then(respuesta => (respuesta.ok)?respuesta.json():respuesta.json().then(data => Promise.reject(data.error))) 
        .then(data => login(data, router))
        .catch(mensaje => display_toast(mensaje,'Info','primary'))   
    }
    catch(e){
        display_toast(e,'Info','primary');
    }
    }
    
        
